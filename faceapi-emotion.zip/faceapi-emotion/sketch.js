// ===================code for tracking facial movement and create input box and button================

// function setup() {
//   createCanvas(windowWidth, windowHeight);
  
// }

// function draw() {
//   background(0);
//   fill(255);
//   text(window.theExpression,100,100);
//   console.log(window.theExpression);
// }


// let myInput;
// let mTest;
// let button;
// function setup() {
//   mTest=false;
//   createCanvas(windowWidth, windowHeight);
//   myInput = createInput('Send chat...');
//   myInput.position(300, 300);
//   button = createButton('Send >');
//   button.position(450, 300);
//   describe('The text "hello!" written at the center of a gray square. A text box beneath the square also says "hello!". The text in the square changes when the user types something new in the input bar.');
// }

// function draw() {
//   background(0);
//   fill(255);
//   text(window.theExpression,100,100);
//   console.log(window.theExpression);
//   // Use the input to display a message.
//   let msg = myInput.value();
//     button.mousePressed(mTest_function);
//   if (mTest){
//   text(msg, 525, 55);
// }
// }

// function mTest_function(){
//   mTest=~mTest;
// }

// ================================code for Sentiment Analysis =====================================

// let sentiment;
// let submitBtn;
// let inputBox;
// let sentimentResult;

// function preload() {
//   // Initialize the sentiment analysis model
//   sentiment = ml5.sentiment("MovieReviews");
// }

// function setup() {
//   noCanvas();

//   // Setup the DOM elements
//   inputBox = createInput("Today is the happiest day and is full of rainbows!");
//   inputBox.attribute("size", "75");
//   submitBtn = createButton("submit");
//   sentimentResult = createP("Sentiment confidence:");

//   // Start predicting when the submit button is pressed
//   submitBtn.mousePressed(getSentiment);
// }

// function getSentiment() {
//   // Use the value of the input box
//   let text = inputBox.value();

//   // Start making the prediction
//   sentiment.predict(text, gotResult);
// }

// function gotResult(prediction) {
//   // Display sentiment result via the DOM
//   sentimentResult.html("Sentiment confidence: " + prediction.confidence);
// }

// // Start predicting when the Enter key is pressed
// function keyPressed() {
//   if (keyCode == ENTER) {
//     getSentiment();
//   }
// }



// ----- Stage 0 -----
let NameInput;
let savedUsername = "User";
let Stage0 = true;  
let Stage1 = false; 

function setup() {
  createCanvas(windowWidth, windowHeight);
  NameInput = createInput();
  NameInput.position(windowWidth/2-NameInput.width/2, windowHeight/2);
  ConfirmBtn = createButton("Confirm");
  ConfirmBtn.position(windowWidth/2+NameInput.width/2, windowHeight/2);
  ConfirmBtn.mousePressed(saveName);
}

function draw() {
  fill("White");
  text("My Username", windowWidth/2-NameInput.width, windowHeight/2+NameInput.height/1.5);
}

function saveName () {
  savedUsername = NameInput.value();
  Stage0 = false;
  Stage1 = true;
}

// ----- Stage 1 -----
// ML5 Sentiment Variables
let sentiment;
let sendBtn;
let inputBox;
let sentimentResult;

// P5.js Display Variables
// This variable holds the text that was LAST submitted and is displayed on the Canvas.
// Initialized as an empty string now, so nothing appears until the first submit.
let analyzedChat = ""; // the string is empty at the beginning
// State Variable to track if a chat was ever sent
let ChatSent = false;
let MeroResponse = "";

// PRELOAD
function preload() {
  // Initialize the sentiment analysis model (ml5.sentiment)
  sentiment = ml5.sentiment("MovieReviews");
}

// SETUP
function setup() {
  // Create Canvas
  createCanvas(windowWidth, windowHeight*2/3);

  textWrap(CHAR); //make sure the text auto goes to the next line

  // Setup the DOM elements (input box and send button)
  inputBox = createInput("Send Chat...");
  inputBox.attribute("size", "75");
  sendBtn = createButton("Send");
  sentimentResult = createP("Sentiment Confidence:");


  // Start predicting when the submit button is pressed
  sendBtn.mousePressed(analyzeAndDisplay);
  

}

// DRAW 
function draw() {
  background(20);
  fill(255);


  // Only output text on the screen when user has sent something
  if (ChatSent) {
    // Display the text stored in analyzedText after the user hits send
    textAlign(LEFT);
    textSize(15);
    text("[" + savedUsername + "] " + analyzedChat, windowWidth*0.8, 30, windowWidth*0.15);
    textAlign(CENTER);
    textSize(18);
    text(MeroResponse, windowWidth/2, windowHeight*0.5);
    // Display the submitted text. This relies on analyzeAndDisplay updating analyzedText.
  }
}

// FUNCTIONS
// start this function and both output the text on to the screen and start the prediction
function analyzeAndDisplay() {
    // use the value of the input box
    analyzedChat = inputBox.value();
    // set the chatsent to true so that the text gets displayed on the screen
    ChatSent = true;
    // Start making the prediction
    getSentiment();
}

function getSentiment() {
  // Use the value of the input box
  let text = inputBox.value();
  // Start making the prediction
  sentiment.predict(text, gotResult);
}

function gotResult(prediction) {
  // Display sentiment result via the DOM
  sentimentResult.html("Sentiment confidence: " + prediction.confidence);
  // let the character respond to user's chat according to its sentiment confidence
  let confidence = prediction.confidence;
  if (confidence > 0.7) { // positive
    MeroResponse = "Going well? Good for you~~I am doing good, too. ";
  } else if (confidence > 0.4) { // neutral
    MeroResponse = "Just okay? Well...you survived another day, so that's good news. ";
  } else { // negative
    MeroResponse = "Oh, wow, that's so bad......Well, I'm glad everything is going well with me~~";
  }
}

// Start analyzing and display when the Enter key is pressed
function keyPressed() {
  if (keyCode === ENTER) {
    analyzeAndDisplay();
  }
}







